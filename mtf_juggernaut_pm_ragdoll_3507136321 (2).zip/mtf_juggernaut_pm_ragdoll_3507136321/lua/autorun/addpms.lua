AddCSLuaFile()
player_manager.AddValidModel("MTF - Juggernaut", "models/arty/codmw2022/sp/shadow company/elite 3/grunt_pm.mdl")